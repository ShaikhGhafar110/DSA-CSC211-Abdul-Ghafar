/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DSA_Lab_05;

/**
 *
 * @author User
 */
public class stackarray {
    int size;
    int []arr;
    int top;
    public stackarray(int size){
        this.size=size;
        arr =new int[size];
        top=-1;
    }
    
    public void push(int data){
    if(top>=size-1){
        System.out.println("stack is full");
        return;
    }
    arr[++top]=data;
    }
    
    public int pop(){
    if(top<0){
        System.out.println("Stack is underflow");
    return -1;
    }
    return top--;
    }
    
    public boolean isEmpty(){
    return top==-1;
    }
    
    public boolean Full(){
    return top==size-1;
    }
    
    public int peek(){
      if(top<0){
        System.out.println("Stack is underflow");
    return -1;
    }
      return arr[top];
    }
    
    public void print(){
    if(top<=0){
        System.out.println("Stack is underflow");
        
    }
    else{
    for(int i=top; i>=0; i--){
        System.out.println(arr[i]+" ");
    }
        System.out.println();
    }
    }
    
    
    public static void main(String[] args) {
     stackarray s=new stackarray(5);
     s.push(1);
    s.push(2);
    s.push(3);
    s.push(4);
    s.push(5);
    s.pop();
        System.out.println( "Top Element is :"+s.peek());
    s.print();
    }
    
}
