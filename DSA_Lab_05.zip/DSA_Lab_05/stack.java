/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */    
package DSA_Lab_05;

/**
 *
 * @author User
 */
public class stack {
    class Node{
    Node next; 
    int data;
     public Node(int data){
       this.data=data;
     }}
    private Node top;
    private int length;
    public stack(){
        this.top=null;
        this.length=0;
    }
    public int length(){
    return length;
    }
    
    public boolean isEmpty(){
    return length==0;
    }
    
    public  void push(int data){
        Node temp = new Node(data);
        temp.next=top;
        top=temp;
        length++;
    }
    
    public int pop(){
        if(isEmpty()){
            System.out.println("Stack, is Undeflow");
        }
    int result=top.data;
    top=top.next;
    length--;
    return result;
    }
    
    public int peek(){
    if(isEmpty()){
        System.out.println("Stack Underflow");
    }
    return top.data;
    }
    
    public void PrintAll(){
    if(top==null){
        System.out.println("Stack is Null");
       }             
    else{
   Node current=top;
   while(current!=null){
       System.out.println(current.data);
       current=current.next;
   }
        System.out.println();
    }}
    public static void main(String[] args) {
        stack s= new stack();
        s.push(1);
        s.push(2);
        s.push(3);
        s.push(4);
        s.push(5);
        s.pop();
        System.out.println("Top: "+s.peek());
        s.PrintAll();
        
    }
}