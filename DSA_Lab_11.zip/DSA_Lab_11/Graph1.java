/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package graph1;

/**
 *
 * @author User
 */
import java.util.Scanner;

public class Graph1 {
    private int[][] adjacencyMatrix;
    private int numberOfVertices;
    public Graph1(int vertices){
        this.numberOfVertices = vertices;
        adjacencyMatrix = new int[vertices][vertices];}
    public void addEdge(int u, int v) {
        adjacencyMatrix[u - 1][v - 1] = 1;}
    public void displayAdjacencyMatrix() {
        System.out.println("Adjacency Matrix:");
        System.out.print("   "); 
        for (int i = 1; i <= numberOfVertices; i++){
            System.out.print(i + " ");
        }
        System.out.println();
        for (int i = 0; i < numberOfVertices; i++){
            System.out.print((i + 1) + " | "); 
            for (int j = 0; j < numberOfVertices; j++){
                System.out.print(adjacencyMatrix[i][j] + " ");}
            System.out.println();}}

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of vertices: ");
        int vertices = scanner.nextInt();
        Graph graph = new Graph(vertices);
        System.out.print("Enter number of edges: ");
        int edges = scanner.nextInt();
        System.out.println("Enter the edges (u, v) pairs:");
        for (int i = 0; i < edges; i++){
            int u = scanner.nextInt();
            int v = scanner.nextInt();
            graph.addEdge(u, v);
        }
        graph.displayAdjacencyMatrix();
        scanner.close();}}