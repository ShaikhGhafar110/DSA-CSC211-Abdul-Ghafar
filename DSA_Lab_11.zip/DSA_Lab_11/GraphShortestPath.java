/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package graph1;

/**
 *
 * @author User
 */
import java.util.Arrays;
import java.util.Scanner;

public class GraphShortestPath{
    private int[][] adjacencyMatrix;
    private int numberOfVertices;
    public GraphShortestPath(int vertices){
        this.numberOfVertices = vertices;
        adjacencyMatrix = new int[vertices][vertices];}
    public void addEdge(int u, int v) {
        adjacencyMatrix[u-1][v-1]=1;}
    public void displayAdjacencyMatrix(){
        System.out.println("Adjacency Matrix:");
        System.out.print("   ");
        for (int i = 1; i <= numberOfVertices; i++){
            System.out.print(i + " ");}
        System.out.println();
        for (int i = 0; i < numberOfVertices; i++){
            System.out.print((i + 1) + " | "); 
            for (int j = 0; j < numberOfVertices; j++) {
                System.out.print(adjacencyMatrix[i][j] + " ");}
            System.out.println();}}
    public void findShortestPath(int start, int destination){
        int[] distances = new int[numberOfVertices];
        boolean[] visited = new boolean[numberOfVertices];
        int[] previous = new int[numberOfVertices];
        Arrays.fill(distances, Integer.MAX_VALUE);
        Arrays.fill(previous, -1);
        distances[start - 1] = 0; 
        for (int i = 0; i < numberOfVertices - 1; i++){
            int u = selectMinVertex(distances, visited);
            visited[u] = true;

            for (int v = 0; v < numberOfVertices; v++){
                if (adjacencyMatrix[u][v] == 1 && !visited[v]){
                    int newDist = distances[u] + 1; 
                    if (newDist < distances[v]){
                        distances[v] = newDist;
                        previous[v] = u;}}}}

        printShortestPath(previous, distances, start - 1, destination - 1);
    }
    private int selectMinVertex(int[] distances, boolean[] visited){
        int minVertex = -1;
        for (int i = 0; i < distances.length; i++){
            if (!visited[i] && (minVertex == -1 || distances[i] < distances[minVertex])){
                minVertex = i;
            }
        }
        return minVertex;
    }    private void printShortestPath(int[] previous, int[] distances, int start, int destination){
        if (distances[destination] == Integer.MAX_VALUE){
            System.out.println("No path exists from " + (start + 1) + " to " + (destination + 1));
            return;}
        StringBuilder path = new StringBuilder();
        for (int at = destination; at != -1; at = previous[at]){
            path.insert(0, (at + 1) + (at == start ? "" : " → "));}
        System.out.println("Shortest Path: " + path);
        System.out.println("Length: " + distances[destination]);}
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of vertices: ");
        int vertices = scanner.nextInt();
        GraphShortestPath graph = new GraphShortestPath(vertices);
        System.out.print("Enter number of edges: ");
        int edges = scanner.nextInt();
        System.out.println("Enter the edges (u, v) pairs:");
        for (int i = 0; i < edges; i++){
            int u = scanner.nextInt();
            int v = scanner.nextInt();
            graph.addEdge(u, v);
        }

   
    }}
